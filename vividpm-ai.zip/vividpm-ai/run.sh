#!/bin/bash
# ============================================================
# VividPM AI — One-command startup
# ============================================================
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

echo -e "${CYAN}${BOLD}"
echo "  ╦  ╦┬┬  ╦┌┬┐╔═╗╔╦╗  ╔═╗╦"
echo "  ╚╗╔╝│╚╗╔╝ ││╠═╝║║║  ╠═╣║"
echo "   ╚╝ ╩ ╚╝ ─┴┘╩  ╩ ╩  ╩ ╩╩═╝"
echo -e "${NC}${BOLD}  VividPM AI — AI-Powered Problem Solving Platform${NC}"
echo ""

[ ! -f .env ] && { cp .env.example .env 2>/dev/null; echo -e "${RED}❌ .env not found. Edit .env with your OPENAI_API_KEY then re-run.${NC}"; exit 1; }
grep -q "sk-your-openai" .env 2>/dev/null && { echo -e "${RED}❌ Set a real OPENAI_API_KEY in .env first.${NC}"; exit 1; }

mkdir -p uploads generated config md_frameworks logs
echo -e "${GREEN}✓ Directories ready${NC}"

PYTHON=$(command -v python3 || command -v python)
echo -e "${GREEN}✓ Python: $($PYTHON --version)${NC}"

PORT=${FLASK_PORT:-5000}
lsof -ti:$PORT | xargs kill -9 2>/dev/null || true
sleep 1

export $(grep -v '^#' .env | xargs) 2>/dev/null || true

echo -e "${CYAN}▶ Starting VividPM AI on http://127.0.0.1:$PORT${NC}"
$PYTHON app.py
