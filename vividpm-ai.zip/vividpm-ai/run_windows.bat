@echo off
echo ============================================
echo   VividPM AI - AI-Powered Problem Solver
echo ============================================
echo.
if not exist .env (
    copy .env.example .env
    echo Please edit .env with your OPENAI_API_KEY and re-run.
    pause
    exit /b 1
)
mkdir uploads 2>nul
mkdir generated 2>nul
mkdir config 2>nul
mkdir md_frameworks 2>nul
mkdir logs 2>nul
echo Starting VividPM AI...
python app.py
pause
