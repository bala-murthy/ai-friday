"""Configuration manager — reads/writes config/modules.json."""
import json
from pathlib import Path
from typing import Any

CONFIG_FILE = Path("config/modules.json")


def ensure_config_dir():
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    ensure_config_dir()
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {"module_count": 0, "modules": []}


def save_config(data: dict[str, Any]) -> None:
    ensure_config_dir()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_module(module_id: int) -> dict | None:
    cfg = load_config()
    for m in cfg.get("modules", []):
        if m["id"] == module_id:
            return m
    return None


def update_module_status(module_id: int, status: str) -> None:
    cfg = load_config()
    for m in cfg.get("modules", []):
        if m["id"] == module_id:
            m["status"] = status
            break
    save_config(cfg)
