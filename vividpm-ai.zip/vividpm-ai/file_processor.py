"""Handles reading uploaded files of various types into text/CSV strings."""
import io, os
from pathlib import Path


def extract_text(filepath: str) -> str:
    """Extract text content from any supported file type."""
    p = Path(filepath)
    ext = p.suffix.lower()

    if ext in (".txt", ".md"):
        return p.read_text(encoding="utf-8", errors="replace")

    if ext == ".csv":
        return p.read_text(encoding="utf-8", errors="replace")

    if ext in (".xlsx", ".xls"):
        try:
            import pandas as pd
            df = pd.read_excel(filepath, nrows=200)
            return df.to_csv(index=False)
        except Exception as e:
            return f"[Excel read error: {e}]"

    if ext == ".pdf":
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(filepath)
            text = "\n\n".join(page.get_text() for page in doc)
            doc.close()
            return text[:20000]
        except Exception as e:
            return f"[PDF read error: {e}]"

    if ext == ".docx":
        try:
            from docx import Document
            doc = Document(filepath)
            return "\n".join(p.text for p in doc.paragraphs if p.text)[:20000]
        except Exception as e:
            return f"[DOCX read error: {e}]"

    if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        return f"[Image file: {p.name} — describe the content you need generated based on this image]"

    return f"[Unsupported file type: {ext}]"


def get_csv_preview(filepath: str, rows: int = 5) -> list[dict]:
    """Return first N rows of a CSV/Excel as list of dicts."""
    try:
        import pandas as pd
        ext = Path(filepath).suffix.lower()
        df = pd.read_excel(filepath, nrows=rows) if ext in (".xlsx", ".xls") else pd.read_csv(filepath, nrows=rows)
        return df.fillna("").to_dict(orient="records")
    except Exception:
        return []


def get_csv_columns(filepath: str) -> list[str]:
    try:
        import pandas as pd
        ext = Path(filepath).suffix.lower()
        df = pd.read_excel(filepath, nrows=0) if ext in (".xlsx", ".xls") else pd.read_csv(filepath, nrows=0)
        return list(df.columns)
    except Exception:
        return []
