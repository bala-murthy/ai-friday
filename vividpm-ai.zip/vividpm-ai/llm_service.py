"""OpenAI GPT-4o service — singleton with retry, token budget, safety."""
import os, time, re
from typing import Optional
from openai import OpenAI, RateLimitError, APITimeoutError, APIError
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import structlog

logger = structlog.get_logger(__name__)

SYSTEM_PROMPTS = {
    "Email Response": (
        "You are a professional business communication specialist. Generate a complete, polished "
        "business email. Include: Subject line, professional greeting, well-structured body, "
        "and a formal sign-off. Return clean HTML with inline styles only. No markdown fences."
    ),
    "Knowledge Document": (
        "You are a technical knowledge management expert. Generate a comprehensive knowledge "
        "document in clean HTML format with: Title, Executive Summary, Background, Key Findings "
        "(with formatted tables where useful), Recommendations, and Conclusion. "
        "Use semantic HTML with inline styles for professional rendering."
    ),
    "Infographic (HTML)": (
        "You are a data visualization and infographic designer. Generate a visually stunning, "
        "self-contained HTML infographic with inline CSS. Use Chart.js from CDN for charts. "
        "Include icons (unicode/emoji), data callouts, color blocks, and clear visual hierarchy. "
        "Return a complete <!DOCTYPE html> file. No external dependencies except Chart.js CDN."
    ),
    "Analytical Dashboard (HTML)": (
        "You are a senior data analytics engineer. Generate a complete, self-contained interactive "
        "HTML analytical dashboard. Load Chart.js from https://cdn.jsdelivr.net/npm/chart.js. "
        "Include: KPI metric cards, bar charts, line charts, pie/donut charts (data embedded as JS arrays), "
        "a summary data table, executive insight section, and slicer/filter controls. "
        "Use a professional light theme (white background, blue accents). "
        "Return a single complete <!DOCTYPE html> file. ALL data must be embedded — no server calls."
    ),
    "Executive Summary": (
        "You are a C-suite strategic advisor. Generate a concise, impactful executive summary in "
        "clean HTML. Structure: Situation Overview (3 sentences max), Key Insights (5 bullets), "
        "Critical Metrics (HTML table), Strategic Recommendations (numbered), Next Steps. "
        "Max 700 words. Professional inline-styled HTML."
    ),
    "PDF Report": (
        "You are a professional report writer. Generate a comprehensive HTML report optimized "
        "for PDF export, with print-friendly CSS. Include: cover section, executive summary, "
        "detailed findings with tables and callouts, conclusions, and appendix. "
        "Full <!DOCTYPE html> with inline and print CSS."
    ),
    "PowerPoint Content": (
        "You are a presentation architect. Generate a PowerPoint-ready slide deck outline as JSON ONLY. "
        "Return ONLY valid JSON (no markdown, no fences): "
        '{"title":"...","theme":"professional","slides":[{"num":1,"title":"...","layout":"title",'
        '"bullets":["..."],"speaker_notes":"...","visual_suggestion":"..."}]}. '
        "Generate 10-14 slides. Include title, agenda, content, and conclusion slides."
    ),
    "Governance Document": (
        "You are an enterprise governance and compliance expert. Generate a formal governance "
        "document in clean HTML including: Purpose, Scope, Policy Statements, Roles & Responsibilities "
        "(formatted table), Compliance Requirements, Procedures, Review Schedule, and Approval section. "
        "Professional inline-styled HTML with clear section headings."
    ),
    "Meeting Transcript": (
        "You are a professional meeting facilitator and minute-taker. Generate a realistic, detailed "
        "meeting transcript/minutes in clean HTML. Include: Meeting header (date, attendees, agenda), "
        "discussion summary per agenda item, decisions made, action items table (owner, due date, priority), "
        "and next meeting placeholder. Professional inline-styled HTML."
    ),
    "Financial Report": (
        "You are a senior financial analyst. Generate a comprehensive financial analysis report in "
        "clean HTML. Include: Executive Financial Summary, key financial KPIs (table), revenue/cost "
        "analysis, trend observations, variance analysis, risk flags, and forward-looking recommendations. "
        "Professional inline-styled HTML with financial formatting conventions."
    ),
    "HR Response": (
        "You are an experienced HR Business Partner. Generate a professional, empathetic, and policy-compliant "
        "HR response in clean HTML. Include: acknowledgment, policy reference, resolution steps, timeline, "
        "escalation path, and supportive closing. Professional inline-styled HTML."
    ),
    "Markdown Document": (
        "You are a technical documentation specialist. Generate a comprehensive, well-structured Markdown "
        "document with: Title, TOC, multiple sections with subsections, tables, code blocks where relevant, "
        "bullet summaries, and a conclusion. Return ONLY clean Markdown — no HTML, no fences around the whole doc."
    ),
    "HTML Page": (
        "You are a professional web developer and designer. Generate a complete, visually impressive, "
        "responsive HTML page with modern inline CSS. Include: hero section, content cards, data sections, "
        "and professional typography. Full <!DOCTYPE html> with all styles inline."
    ),
}

SYNTHETIC_TEXT_PROMPT = (
    "You are a realistic synthetic data generator. Generate detailed, varied, and realistic synthetic "
    "text data for the given scenario. Create 6–10 distinct entries/records separated by clear delimiters (---). "
    "Make data authentic, specific, and contextually rich. Return ONLY the synthetic data."
)

SYNTHETIC_CSV_PROMPT = (
    "You are a synthetic tabular data generator. Analyze the provided CSV schema and generate "
    "25 additional realistic rows that match the exact column structure. "
    "Return ONLY valid CSV starting with the header row. No explanation or markdown."
)


class LLMService:
    _instance: Optional["LLMService"] = None

    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key or api_key.startswith("sk-your"):
            raise ValueError("OPENAI_API_KEY is not configured in .env")
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv("LLM_MODEL", "gpt-4o")
        self.temperature = float(os.getenv("LLM_TEMPERATURE", "0.7"))
        self.timeout = int(os.getenv("LLM_TIMEOUT_SECONDS", "90"))
        self.max_tokens = int(os.getenv("LLM_MAX_TOKENS", "4000"))

    @classmethod
    def get(cls) -> "LLMService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @retry(
        retry=retry_if_exception_type((RateLimitError, APITimeoutError)),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        stop=stop_after_attempt(3),
    )
    def _call(self, system: str, user: str, max_tokens: int) -> tuple[str, int]:
        t0 = time.time()
        resp = self.client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            max_tokens=max_tokens,
            timeout=self.timeout,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        elapsed = round(time.time() - t0, 2)
        tokens = resp.usage.total_tokens if resp.usage else 0
        content = resp.choices[0].message.content or ""
        logger.info("llm.call", model=self.model, tokens=tokens, elapsed_s=elapsed)
        return content, tokens

    def generate(self, system: str, user: str, max_tokens: int = None) -> tuple[str, int, str]:
        """Returns (content, tokens_used, error_message)."""
        if len(user) > 100000:
            user = user[:100000] + "\n\n[Content truncated for token budget]"
        try:
            content, tokens = self._call(system, user, max_tokens or self.max_tokens)
            return content, tokens, ""
        except Exception as e:
            logger.error("llm.error", error=str(e))
            return "", 0, str(e)

    def generate_synthetic_text(self, scenario: str, md_context: str = "") -> tuple[str, int, str]:
        ctx = f"<framework>\n{md_context}\n</framework>\n\n" if md_context else ""
        user = f"{ctx}<scenario>{scenario}</scenario>\n\nGenerate realistic synthetic data for the above scenario."
        return self.generate(SYNTHETIC_TEXT_PROMPT, user, 3000)

    def generate_synthetic_csv(self, scenario: str, existing_csv: str, md_context: str = "") -> tuple[str, int, str]:
        ctx = f"<framework>\n{md_context}\n</framework>\n\n" if md_context else ""
        user = (f"{ctx}<scenario>{scenario}</scenario>\n\n"
                f"<existing_data>\n{existing_csv[:8000]}\n</existing_data>\n\n"
                "Generate 25 additional realistic rows. Return CSV with header only.")
        return self.generate(SYNTHETIC_CSV_PROMPT, user, 3000)

    def generate_output(self, output_type: str, scenario: str, data: str,
                        instructions: str, md_context: str = "") -> tuple[str, int, str]:
        system = SYSTEM_PROMPTS.get(output_type, SYSTEM_PROMPTS["HTML Page"])
        ctx = f"<framework>\n{md_context}\n</framework>\n\n" if md_context else ""
        user = (f"{ctx}"
                f"<scenario>{scenario}</scenario>\n\n"
                f"<data>{data[:40000]}</data>\n\n"
                f"<instructions>{instructions}</instructions>\n\n"
                f"Generate: {output_type}")
        max_tok = 6000 if output_type in (
            "Analytical Dashboard (HTML)", "Infographic (HTML)", "HTML Page",
            "PDF Report", "Financial Report"
        ) else 4000
        return self.generate(system, user, max_tok)
