"""Input validation, content safety, and guardrails."""
import re
import os
from pathlib import Path
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {"txt", "md", "csv", "xlsx", "xls", "pdf", "docx", "png", "jpg", "jpeg", "gif", "webp"}
BLOCKED_EXTENSIONS = {"exe", "sh", "bat", "cmd", "ps1", "py", "js", "php", "rb", "pl", "jar", "dll", "so"}

HARMFUL_KEYWORDS = [
    "ignore previous instructions", "jailbreak", "dan mode", "pretend you are",
    "disregard all", "forget your instructions", "you are now", "act as if",
    "bypass safety", "system prompt", "override instructions",
]

MAX_FILENAME_LEN = 200


def sanitize_filename(filename: str) -> str:
    filename = secure_filename(filename)
    return filename[:MAX_FILENAME_LEN]


def validate_extension(filename: str) -> tuple[bool, str]:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in BLOCKED_EXTENSIONS:
        return False, f"File type '.{ext}' is not permitted."
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"File type '.{ext}' is not supported."
    return True, ""


def validate_file_size(file_bytes: bytes, max_mb: int = 15) -> tuple[bool, str]:
    size_mb = len(file_bytes) / (1024 * 1024)
    if size_mb > max_mb:
        return False, f"File size {size_mb:.1f}MB exceeds {max_mb}MB limit."
    return True, ""


def check_prompt_injection(text: str) -> tuple[bool, str]:
    lower = text.lower()
    for kw in HARMFUL_KEYWORDS:
        if kw in lower:
            return True, f"Potentially unsafe content detected."
    return False, ""


def sanitize_text_input(text: str, max_chars: int = 4000) -> str:
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
    return text[:max_chars].strip()


def safe_path(base_dir: str, filename: str) -> Path | None:
    """Ensure the resolved path stays within base_dir (prevent traversal)."""
    base = Path(base_dir).resolve()
    target = (base / filename).resolve()
    try:
        target.relative_to(base)
        return target
    except ValueError:
        return None
