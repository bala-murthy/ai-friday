# Executive Summary Framework

## Audience
C-suite executives and senior leadership.

## Structure (strict)
1. Situation — 2-3 sentences max
2. Key Insights — 5 bullets, max 20 words each
3. Critical Metrics — Table: Metric | Current | Target | Status
4. Strategic Recommendations — 3-5 numbered items
5. Next Steps — Action | Owner | Due Date table

## Writing Rules
- Max 600 words total
- Numbers formatted: 1,234 and $1.2M
- RAG: Green = On Track / Amber = At Risk / Red = Off Track
- Lead with business impact first
