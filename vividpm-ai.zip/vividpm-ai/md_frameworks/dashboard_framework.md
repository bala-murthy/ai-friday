# Analytical Dashboard Framework

## Required Sections
1. KPI Summary Row — 4 metric cards at top
2. Primary Chart — Main trend (bar or line)
3. Secondary Charts — Pie/donut + secondary bar
4. Data Table — Top 10 records
5. Executive Insights — 3-5 bullet summary

## Chart.js CDN
Load from: https://cdn.jsdelivr.net/npm/chart.js
All data embedded in JS arrays. No external API calls.

## Output Format
Single self-contained HTML file. All CSS inline.
