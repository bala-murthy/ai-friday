# HR Governance Framework

## Tone & Communication Standards
- Use empathetic, professional, and inclusive language
- Always acknowledge the employee concern first before presenting resolution
- Escalation path: HR Executive → HR Director → CHRO

## Response Structure
1. Acknowledgment of the concern
2. Policy context / background
3. Resolution steps with clear timelines
4. Escalation path if unresolved
5. Supportive closing with contact details

## Confidentiality Notice
All HR communications must include: "This response is confidential and intended solely for the recipient."
