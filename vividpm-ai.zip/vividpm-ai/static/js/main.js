/* ============================================================
   VividPM AI — Shared JavaScript Utilities
   ============================================================ */

const API = {
  base: '',
  async get(path) {
    const r = await fetch(this.base + path);
    return r.json();
  },
  async post(path, body) {
    const r = await fetch(this.base + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return r.json();
  },
  async upload(path, formData) {
    const r = await fetch(this.base + path, { method: 'POST', body: formData });
    return r.json();
  }
};

// ── Toast Notifications ───────────────────────────────────
const Toast = {
  container: null,
  init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(msg, type = 'info', duration = 3500) {
    this.init();
    const icons = { success: '✅', error: '❌', warn: '⚠️', info: 'ℹ️' };
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${msg}</span>`;
    this.container.appendChild(t);
    setTimeout(() => {
      t.classList.add('hiding');
      setTimeout(() => t.remove(), 350);
    }, duration);
  },
  success(m, d) { this.show(m, 'success', d); },
  error(m, d)   { this.show(m, 'error', d || 5000); },
  warn(m, d)    { this.show(m, 'warn', d); },
  info(m, d)    { this.show(m, 'info', d); }
};

// ── Spinner ───────────────────────────────────────────────
const Spinner = {
  el: null,
  init() {
    if (!this.el) {
      this.el = document.createElement('div');
      this.el.className = 'spinner-overlay';
      this.el.innerHTML = `
        <div class="spinner"></div>
        <div class="spinner-text" id="spinnerText">Processing…</div>
        <div class="spinner-sub" id="spinnerSub">Please wait, this may take a moment.</div>`;
      document.body.appendChild(this.el);
    }
  },
  show(msg = 'Processing…', sub = 'Please wait, this may take a moment.') {
    this.init();
    document.getElementById('spinnerText').textContent = msg;
    document.getElementById('spinnerSub').textContent = sub;
    this.el.classList.add('active');
  },
  hide() { this.el && this.el.classList.remove('active'); }
};

// ── Accordion sections ────────────────────────────────────
function initAccordions() {
  document.querySelectorAll('.section-card-header').forEach(header => {
    header.addEventListener('click', () => {
      const body = header.nextElementSibling;
      const chevron = header.querySelector('.section-chevron');
      const isOpen = body.classList.contains('open');
      // Close all
      document.querySelectorAll('.section-card-body').forEach(b => b.classList.remove('open'));
      document.querySelectorAll('.section-card-header').forEach(h => h.classList.remove('open'));
      document.querySelectorAll('.section-chevron').forEach(c => c.classList.remove('open'));
      // Open clicked if was closed
      if (!isOpen) {
        body.classList.add('open');
        header.classList.add('open');
        chevron && chevron.classList.add('open');
      }
    });
  });
}

// ── Open first accordion by default ──────────────────────
function openFirstAccordion() {
  const first = document.querySelector('.section-card-header');
  if (first) first.click();
}

// ── Drag & Drop Upload ────────────────────────────────────
function initUploadZone(zoneId, inputId, onFile) {
  const zone = document.getElementById(zoneId);
  const input = document.getElementById(inputId);
  if (!zone || !input) return;

  zone.addEventListener('click', () => input.click());
  input.addEventListener('change', () => {
    if (input.files[0]) onFile(input.files[0]);
  });
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.classList.remove('dragover');
    if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]);
  });
}

// ── Character counter ─────────────────────────────────────
function initCharCounter(inputId, counterId, max) {
  const input = document.getElementById(inputId);
  const counter = document.getElementById(counterId);
  if (!input || !counter) return;
  const update = () => {
    const len = input.value.length;
    counter.textContent = `${len}/${max}`;
    counter.className = 'char-count' + (len > max * 0.85 ? ' warn' : '');
  };
  input.addEventListener('input', update);
  update();
}

// ── Format file size ──────────────────────────────────────
function fmtSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + ' KB';
  return (bytes/1024/1024).toFixed(1) + ' MB';
}

// ── Build status badge HTML ───────────────────────────────
function statusBadge(status) {
  const map = {
    'Not Started': 'badge-ns',
    'In Progress': 'badge-ip',
    'Completed':   'badge-done'
  };
  return `<span class="badge ${map[status] || 'badge-ns'}">${status}</span>`;
}

// ── Stepper update ────────────────────────────────────────
function updateStepper(currentStep) {
  document.querySelectorAll('.step').forEach((step, i) => {
    const circle = step.querySelector('.step-circle');
    const label  = step.querySelector('.step-label');
    const conn   = step.querySelector('.step-connector');
    const n = i + 1;
    if (n < currentStep) {
      circle.className = 'step-circle done'; circle.textContent = '✓';
      label.className  = 'step-label';
      conn && conn.classList.add('done');
    } else if (n === currentStep) {
      circle.className = 'step-circle active'; circle.textContent = n;
      label.className  = 'step-label active';
    } else {
      circle.className = 'step-circle pending'; circle.textContent = n;
      label.className  = 'step-label pending';
      conn && conn.classList.remove('done');
    }
  });
}

// ── Table renderer ────────────────────────────────────────
function renderTable(rows, containerId) {
  if (!rows || rows.length === 0) return;
  const container = document.getElementById(containerId);
  if (!container) return;
  const cols = Object.keys(rows[0]);
  const thead = `<thead><tr>${cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>`;
  const tbody = `<tbody>${rows.map(r =>
    `<tr>${cols.map(c => `<td>${r[c] ?? ''}</td>`).join('')}</tr>`
  ).join('')}</tbody>`;
  container.innerHTML = `<div class="data-table-wrap"><table>${thead}${tbody}</table></div>`;
}

// ── Download helper ───────────────────────────────────────
function downloadFile(filePath, fileName) {
  const a = document.createElement('a');
  a.href = `/api/download?path=${encodeURIComponent(filePath)}`;
  a.download = fileName || 'download';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

// ── Set iframe content ────────────────────────────────────
function setIframeContent(iframeId, html) {
  const iframe = document.getElementById(iframeId);
  if (!iframe) return;
  const doc = iframe.contentDocument || iframe.contentWindow.document;
  doc.open(); doc.write(html); doc.close();
}

// ── Navbar active link ────────────────────────────────────
function setActiveNav() {
  const path = window.location.pathname;
  document.querySelectorAll('.navbar-nav a').forEach(a => {
    a.classList.toggle('active', a.getAttribute('href') === path ||
      (path === '/' && a.getAttribute('href') === '/'));
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setActiveNav();
  initAccordions();
});
