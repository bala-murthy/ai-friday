"""
VividPM AI — Flask Backend
Main application entry point with all routes.
"""
import os, json, time, logging
from pathlib import Path
from datetime import datetime
from flask import (Flask, request, jsonify, send_file, send_from_directory,
                   render_template_string)
from flask_cors import CORS
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
import structlog

load_dotenv()

from config_manager import load_config, save_config, update_module_status
from guardrails import (sanitize_filename, validate_extension, validate_file_size,
                        check_prompt_injection, sanitize_text_input, safe_path)
from file_processor import extract_text, get_csv_preview, get_csv_columns
from output_renderer import save_output, save_synthetic, clean_html, markdown_to_html
from llm_service import LLMService

# ── Logging ──────────────────────────────────────────────────────────────────
Path("logs").mkdir(exist_ok=True)
logging.basicConfig(level=logging.INFO)
structlog.configure(
    processors=[structlog.processors.TimeStamper(fmt="iso"),
                structlog.stdlib.add_log_level,
                structlog.processors.JSONRenderer()],
    logger_factory=structlog.stdlib.LoggerFactory(),
)
logger = structlog.get_logger()

# ── App setup ─────────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder="static", static_url_path="/static")
app.secret_key = os.getenv("FLASK_SECRET_KEY", "vividpm-secret-key-change-me")
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("MAX_UPLOAD_SIZE_MB", "15")) * 1024 * 1024

CORS(app, origins=["http://localhost:5000", "http://127.0.0.1:5000"])

for d in ["uploads", "generated", "config", "md_frameworks", "logs"]:
    Path(d).mkdir(exist_ok=True)

# ── Static page routes ────────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/config-page")
def config_page():
    return send_from_directory("static", "config.html")

@app.route("/workspace")
def workspace_page():
    return send_from_directory("static", "workspace.html")

@app.route("/about")
def about_page():
    return send_from_directory("static", "about.html")

# ── Health ────────────────────────────────────────────────────────────────────
@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "version": "1.0.0", "app": "VividPM AI"})

# ── Config API ────────────────────────────────────────────────────────────────
@app.route("/api/config", methods=["GET"])
def get_config():
    return jsonify(load_config())

@app.route("/api/config", methods=["POST"])
def post_config():
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "No data provided"}), 400
    n = data.get("module_count", 0)
    if not isinstance(n, int) or not (1 <= n <= 15):
        return jsonify({"error": "module_count must be 1–15"}), 400
    modules = data.get("modules", [])
    for m in modules:
        m["title"] = sanitize_text_input(m.get("title", ""), 80)
        m["description"] = sanitize_text_input(m.get("description", ""), 300)
        if "status" not in m:
            m["status"] = "Not Started"
        if "synthetic_required" not in m:
            m["synthetic_required"] = True
    save_config({"module_count": n, "modules": modules})
    logger.info("config.saved", module_count=n)
    return jsonify({"success": True})

@app.route("/api/config/module/<int:mid>/status", methods=["POST"])
def update_status(mid):
    body = request.get_json(force=True) or {}
    status = body.get("status", "In Progress")
    if status not in ("Not Started", "In Progress", "Completed"):
        return jsonify({"error": "Invalid status"}), 400
    update_module_status(mid, status)
    return jsonify({"success": True})

# ── File upload ───────────────────────────────────────────────────────────────
@app.route("/api/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    safe_name = sanitize_filename(f.filename)
    valid, msg = validate_extension(safe_name)
    if not valid:
        return jsonify({"error": msg}), 400

    file_bytes = f.read()
    size_ok, size_msg = validate_file_size(file_bytes)
    if not size_ok:
        return jsonify({"error": size_msg}), 400

    module_id = request.form.get("module_id", "0")
    upload_dir = Path("uploads") / f"module_{module_id}"
    upload_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S_")
    final_name = ts + safe_name
    file_path = upload_dir / final_name
    file_path.write_bytes(file_bytes)

    ext = Path(safe_name).suffix.lower()
    is_tabular = ext in (".csv", ".xlsx", ".xls")
    preview = get_csv_preview(str(file_path)) if is_tabular else []
    columns = get_csv_columns(str(file_path)) if is_tabular else []

    logger.info("file.uploaded", name=final_name, size_kb=round(len(file_bytes)/1024, 1))
    return jsonify({
        "success": True,
        "file_path": str(file_path),
        "file_name": final_name,
        "original_name": f.filename,
        "is_tabular": is_tabular,
        "preview": preview,
        "columns": columns,
        "extension": ext,
    })

@app.route("/api/upload/md-framework", methods=["POST"])
def upload_md_framework():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files["file"]
    safe_name = sanitize_filename(f.filename or "framework.md")
    if not safe_name.endswith(".md"):
        return jsonify({"error": "Only .md files allowed for frameworks"}), 400
    file_bytes = f.read()
    size_ok, msg = validate_file_size(file_bytes, max_mb=2)
    if not size_ok:
        return jsonify({"error": msg}), 400
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_")
    p = Path("md_frameworks") / (ts + safe_name)
    p.write_bytes(file_bytes)
    content = p.read_text(encoding="utf-8", errors="replace")
    return jsonify({"success": True, "file_path": str(p), "content": content, "file_name": p.name})

# ── Synthetic data generation ─────────────────────────────────────────────────
@app.route("/api/synthetic/generate", methods=["POST"])
def generate_synthetic():
    body = request.get_json(force=True) or {}
    module_id = int(body.get("module_id", 0))
    scenario = sanitize_text_input(body.get("scenario", ""), 4000)
    input_type = body.get("input_type", "text")
    file_path = body.get("file_path", "")
    md_context = body.get("md_context", "")

    if not scenario:
        return jsonify({"error": "Scenario is required"}), 400
    injected, inj_msg = check_prompt_injection(scenario)
    if injected:
        return jsonify({"error": inj_msg}), 400

    update_module_status(module_id, "In Progress")
    llm = LLMService.get()
    t0 = time.time()

    if input_type in ("csv", "excel") and file_path:
        safe = safe_path("uploads", Path(file_path).name)
        csv_text = Path(file_path).read_text(encoding="utf-8", errors="replace") if Path(file_path).exists() else ""
        content, tokens, err = llm.generate_synthetic_csv(scenario, csv_text[:8000], md_context)
        if err:
            return jsonify({"error": f"LLM error: {err}"}), 502
        saved = save_synthetic(module_id, content, "csv")
        return jsonify({
            "success": True, "type": "csv", "content": content[:5000],
            "file_path": saved, "tokens": tokens,
            "elapsed": round(time.time()-t0, 2)
        })
    else:
        content, tokens, err = llm.generate_synthetic_text(scenario, md_context)
        if err:
            return jsonify({"error": f"LLM error: {err}"}), 502
        saved = save_synthetic(module_id, content, "txt")
        return jsonify({
            "success": True, "type": "text", "content": content,
            "file_path": saved, "tokens": tokens,
            "elapsed": round(time.time()-t0, 2)
        })

# ── Output generation ─────────────────────────────────────────────────────────
@app.route("/api/output/generate", methods=["POST"])
def generate_output():
    body = request.get_json(force=True) or {}
    module_id = int(body.get("module_id", 0))
    scenario = sanitize_text_input(body.get("scenario", ""), 4000)
    output_type = body.get("output_type", "HTML Page")
    instructions = sanitize_text_input(body.get("instructions", ""), 1000)
    synthetic_data = body.get("synthetic_data", "")
    file_path = body.get("file_path", "")
    md_context = body.get("md_context", "")

    if not scenario:
        return jsonify({"error": "Scenario is required"}), 400
    for field, val in [("scenario", scenario), ("instructions", instructions)]:
        injected, msg = check_prompt_injection(val)
        if injected:
            return jsonify({"error": f"Unsafe content in {field}"}), 400

    # Gather data
    data_text = synthetic_data or ""
    if not data_text and file_path and Path(file_path).exists():
        data_text = extract_text(file_path)

    # Force dashboard for tabular input
    if file_path:
        ext = Path(file_path).suffix.lower()
        if ext in (".csv", ".xlsx", ".xls"):
            output_type = "Analytical Dashboard (HTML)"

    update_module_status(module_id, "In Progress")
    llm = LLMService.get()
    t0 = time.time()
    content, tokens, err = llm.generate_output(output_type, scenario, data_text, instructions, md_context)
    if err:
        return jsonify({"error": f"LLM error: {err}"}), 502

    result = save_output(module_id, output_type, content)
    update_module_status(module_id, "Completed")
    elapsed = round(time.time()-t0, 2)

    # For preview, return clean HTML
    preview_html = content
    if output_type == "Markdown Document":
        preview_html = markdown_to_html(content, output_type)
    elif output_type == "PowerPoint Content":
        from output_renderer import pptx_html_preview
        preview_html = pptx_html_preview(content)
    elif output_type not in ("Analytical Dashboard (HTML)", "Infographic (HTML)", "HTML Page"):
        preview_html = clean_html(content)

    logger.info("output.generated", module_id=module_id, output_type=output_type,
                tokens=tokens, elapsed_s=elapsed)
    return jsonify({
        "success": True,
        "output_type": output_type,
        "preview_html": preview_html,
        "file_path": result.get("file_path", ""),
        "download_name": result.get("download_name", "output.html"),
        "pptx_path": result.get("pptx_path", ""),
        "md_path": result.get("md_path", ""),
        "tokens": tokens,
        "elapsed": elapsed,
    })

# ── File download ─────────────────────────────────────────────────────────────
@app.route("/api/download", methods=["GET"])
def download_file():
    file_path = request.args.get("path", "")
    if not file_path:
        return jsonify({"error": "No path"}), 400
    p = Path(file_path)
    if not p.exists():
        return jsonify({"error": "File not found"}), 404
    # Security: must be under generated/ or md_frameworks/
    allowed_bases = [Path("generated").resolve(), Path("md_frameworks").resolve()]
    resolved = p.resolve()
    if not any(str(resolved).startswith(str(b)) for b in allowed_bases):
        return jsonify({"error": "Access denied"}), 403
    return send_file(str(resolved), as_attachment=True, download_name=p.name)

@app.route("/api/preview", methods=["GET"])
def preview_file():
    file_path = request.args.get("path", "")
    if not file_path:
        return "No path", 400
    p = Path(file_path)
    if not p.exists():
        return "File not found", 404
    allowed_bases = [Path("generated").resolve()]
    if not any(str(p.resolve()).startswith(str(b)) for b in allowed_bases):
        return "Access denied", 403
    content = p.read_text(encoding="utf-8", errors="replace")
    return content, 200, {"Content-Type": "text/html; charset=utf-8"}

# ── List generated outputs ────────────────────────────────────────────────────
@app.route("/api/outputs/<int:module_id>", methods=["GET"])
def list_outputs(module_id):
    out_dir = Path("generated") / f"module_{module_id}"
    if not out_dir.exists():
        return jsonify({"files": []})
    files = [{"name": f.name, "path": str(f), "size_kb": round(f.stat().st_size/1024, 1),
               "modified": datetime.fromtimestamp(f.stat().st_mtime).isoformat()}
             for f in sorted(out_dir.iterdir()) if f.is_file()]
    return jsonify({"files": files})

# ── Error handlers ────────────────────────────────────────────────────────────
@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "File too large. Maximum size is 15MB."}), 413

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def server_error(e):
    logger.error("server_error", error=str(e))
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    host = os.getenv("FLASK_HOST", "127.0.0.1")
    port = int(os.getenv("FLASK_PORT", "5000"))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    print(f"\n{'='*55}")
    print(f"  ⚡ VividPM AI — Starting on http://{host}:{port}")
    print(f"{'='*55}\n")
    app.run(host=host, port=port, debug=debug)
