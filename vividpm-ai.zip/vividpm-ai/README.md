# ⚡ VividPM AI

**AI-Powered Problem Solving Platform**

> Configure modules, upload context, generate synthetic data, and produce rich AI-powered outputs using GPT-4o.

---

## Table of Contents

1. [Overview](#overview)
2. [Features](#features)
3. [Architecture](#architecture)
4. [Folder Structure](#folder-structure)
5. [Prerequisites](#prerequisites)
6. [Setup Instructions](#setup-instructions)
7. [Environment Setup](#environment-setup)
8. [Running Locally](#running-locally)
9. [Usage Guide](#usage-guide)
10. [Supported Output Types](#supported-output-types)
11. [MD Frameworks](#md-frameworks)
12. [Supported File Types](#supported-file-types)
13. [Troubleshooting](#troubleshooting)
14. [Security Notes](#security-notes)

---

## Overview

VividPM AI is a production-grade, Flask-based GenAI web application. It enables users to:

- Configure N modules (1–15) with titles and descriptions
- Upload input files (TXT, MD, CSV, XLSX, PDF, DOCX, Images)
- Upload reusable Markdown framework files to guide AI behavior
- Generate synthetic data using GPT-4o
- Produce 13+ output formats: dashboards, reports, emails, presentations, and more
- Download all generated artifacts locally

All outputs are stored on the local filesystem. No database is required.

---

## Features

| Feature | Description |
|---|---|
| Dynamic module management | Configure 1–15 modules with custom titles |
| GPT-4o synthetic data | Generate realistic text or CSV data for any scenario |
| 13+ output types | From emails to interactive dashboards to PPTX |
| MD Framework injection | Upload `.md` files to control AI tone, format, and rules |
| File upload support | 8 file types including PDF and DOCX |
| Interactive dashboards | Chart.js dashboards from CSV/Excel auto-generated |
| Production guardrails | Prompt injection protection, file validation, rate limiting |
| Download everything | All generated files available for download |
| No database | Pure local filesystem storage |
| Light professional UI | Enterprise-grade responsive interface |

---

## Architecture

```
Browser (Pure HTML/CSS/JS)
         │
         │  HTTP REST
         ▼
┌─────────────────────────────┐
│      Flask Backend          │
│  ┌────────────────────────┐ │
│  │   Route Handlers        │ │
│  │  /api/config           │ │
│  │  /api/upload           │ │
│  │  /api/synthetic/...    │ │
│  │  /api/output/...       │ │
│  └────────────┬───────────┘ │
│               │             │
│  ┌────────────▼───────────┐ │
│  │  Prompt Orchestration  │ │
│  │  llm_service.py        │ │
│  │  output_renderer.py    │ │
│  └────────────┬───────────┘ │
│               │             │
│  ┌────────────▼───────────┐ │
│  │  File Processing       │ │
│  │  file_processor.py     │ │
│  │  guardrails.py         │ │
│  └────────────────────────┘ │
└──────────────┬──────────────┘
               │
    ┌──────────▼──────────┐     ┌─────────────┐
    │  Local Filesystem   │     │  OpenAI API │
    │  /uploads           │     │  GPT-4o     │
    │  /generated         │     └─────────────┘
    │  /config            │
    │  /md_frameworks     │
    └─────────────────────┘
```

---

## Folder Structure

```
vividpm-ai/
│
├── app.py                   # Flask application — all routes
├── config_manager.py        # Config read/write (config/modules.json)
├── guardrails.py            # Input validation, content safety
├── llm_service.py           # OpenAI GPT-4o wrapper with retry
├── file_processor.py        # Extract text from uploaded files
├── output_renderer.py       # Render and save output artifacts
│
├── static/
│   ├── css/
│   │   └── main.css         # Complete light theme stylesheet
│   ├── js/
│   │   └── main.js          # Shared JS utilities (Toast, Spinner, API)
│   ├── index.html           # Home page — module tile grid
│   ├── config.html          # Configuration page
│   ├── workspace.html       # Module workspace — 3-step workflow
│   └── about.html           # About page
│
├── md_frameworks/           # Sample reusable MD instruction files
│   ├── hr_governance.md
│   ├── dashboard_framework.md
│   └── executive_summary_framework.md
│
├── sample_data/             # Sample input files for testing
│   └── sample_hr_data.csv
│
├── uploads/                 # Uploaded files (auto-created)
├── generated/               # Generated outputs (auto-created)
│   └── module_N/            # Per-module outputs
├── config/                  # Configuration storage (auto-created)
│   └── modules.json
├── logs/                    # Application logs (auto-created)
│
├── .env.example             # Template environment file
├── .gitignore
├── requirements.txt         # Python dependencies
├── run.sh                   # One-command startup (macOS/Linux)
├── run_windows.bat          # One-command startup (Windows)
└── README.md
```

---

## Prerequisites

| Requirement | Version | Check |
|---|---|---|
| Python | 3.11+ | `python --version` |
| pip | Latest | `pip --version` |
| OpenAI API Key | GPT-4o access | [platform.openai.com](https://platform.openai.com) |

---

## Setup Instructions

### Step 1 — Unzip and open in VS Code

1. Unzip `vividpm-ai.zip` to a folder of your choice
2. Open **VS Code** → **File → Open Folder** → select `vividpm-ai`
3. Open the integrated terminal: press `` Ctrl+` ``

### Step 2 — Create virtual environment

```bash
# macOS / Linux
python3 -m venv .venv
source .venv/bin/activate

# Windows (Command Prompt)
python -m venv .venv
.venv\Scripts\activate.bat

# Windows (PowerShell)
python -m venv .venv
.venv\Scripts\Activate.ps1
```

You should see `(.venv)` in your terminal prompt.

### Step 3 — Select Python interpreter in VS Code

- Press `Ctrl+Shift+P` → type `Python: Select Interpreter`
- Choose the interpreter showing `.venv`

### Step 4 — Install dependencies

**Using pip:**
```bash
pip install -r requirements.txt
```

**Using UV (faster):**
```bash
# Install UV first if needed
curl -LsSf https://astral.sh/uv/install.sh | sh   # macOS/Linux
# OR: powershell -c "irm https://astral.sh/uv/install.ps1 | iex"  # Windows

# Then install
uv pip install -r requirements.txt
```

**Verify:**
```bash
python -c "import flask, openai, pandas; print('All packages OK')"
```

---

## Environment Setup

### Copy and configure `.env`:

```bash
# macOS / Linux
cp .env.example .env

# Windows
copy .env.example .env
```

### Edit `.env` in VS Code and set your key:

```env
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
FLASK_SECRET_KEY=any-random-string-here
FLASK_HOST=127.0.0.1
FLASK_PORT=5000
```

> ⚠️ **Never commit `.env` to git.** It is in `.gitignore`.

---

## Running Locally

### Option A — One command (macOS/Linux)

```bash
bash run.sh
```

### Option B — One command (Windows)

```cmd
run_windows.bat
```

### Option C — Direct Python (all platforms)

```bash
# Ensure venv is activated first
python app.py
```

### Access the application

| Page | URL |
|---|---|
| 🏠 Home | http://localhost:5000 |
| ⚙️ Configuration | http://localhost:5000/config-page |
| ℹ️ About | http://localhost:5000/about |
| ❤️ Health Check | http://localhost:5000/api/health |

---

## Usage Guide

### Step 1 — Configure Modules

1. Open http://localhost:5000/config-page
2. Set the number of modules (use +/− buttons)
3. Enter a **Title** (required) and **Description** for each module
4. Select a **Default Output Type** for each
5. Toggle **Require synthetic data generation** if needed
6. Click **💾 Save Configuration**

### Step 2 — Open a Module Workspace

1. Return to http://localhost:5000 (Home)
2. Click **Open Module →** on any tile

### Step 3 — Upload Inputs (Step 1 of workspace)

- **Scenario**: Write a detailed description of the problem/context
- **Input File** (optional): Upload TXT, MD, CSV, XLSX, PDF, DOCX, or Image
  - CSV/Excel uploads auto-lock the output type to Analytical Dashboard
- **MD Framework** (optional): Upload a `.md` instruction file (see `md_frameworks/` for samples)
- **Output Type**: Select from 13 options
- **Instructions**: Add specific formatting or tone requirements
- Click **Next: Generate Synthetic Data →**

### Step 4 — Generate Synthetic Data (Step 2)

- **If synthetic is required**: Click **🤖 Generate Synthetic Data**
  - Wait 15–30 seconds for GPT-4o to generate realistic data
  - Review output; download if needed
  - Click **Next: Generate Output →**
- **If not required**: Click **Skip — Generate Output Directly →**

### Step 5 — Generate Output (Step 3)

- Review the summary card showing all settings
- Click **✨ Generate Output**
- Wait 30–90 seconds (HTML dashboards take longer)
- Output renders inline in an iframe preview
- Click **⬇ Download Output** to save the file

---

## Supported Output Types

| Output Type | Description | Format |
|---|---|---|
| **Email Response** | Professional business email with subject + body | HTML |
| **Knowledge Document** | Structured doc with findings, tables, recommendations | HTML |
| **HTML Page** | Responsive, styled standalone web page | HTML |
| **Infographic (HTML)** | Visual infographic with Chart.js charts | HTML |
| **Analytical Dashboard (HTML)** | Interactive KPI dashboard (auto for CSV/Excel) | HTML |
| **Executive Summary** | Concise C-suite summary, max 600 words | HTML |
| **PDF Report** | Print-optimized report with cover + findings | HTML |
| **PowerPoint Content** | 10–14 slide deck | .pptx |
| **Governance Document** | Formal policy/governance doc with tables | HTML |
| **Meeting Transcript** | Meeting minutes with action items table | HTML |
| **Financial Report** | Financial analysis with KPIs + trends | HTML |
| **HR Response** | Empathetic, policy-compliant HR communication | HTML |
| **Markdown Document** | Structured Markdown (also saved as .md) | HTML + .md |

---

## MD Frameworks

MD Framework files (`.md`) let you define AI behavior rules that are injected into every GPT prompt for that module.

**Sample frameworks included:**

| File | Purpose |
|---|---|
| `hr_governance.md` | Tone, structure, and policy rules for HR communications |
| `dashboard_framework.md` | Visual design and chart requirements for dashboards |
| `executive_summary_framework.md` | Structure and writing rules for exec summaries |

**To use:** In the workspace, click the MD Framework upload zone and select your `.md` file. Its contents will be prepended to the AI prompt.

---

## Supported File Types

| Extension | Type | How Used |
|---|---|---|
| `.txt` | Plain text | Extracted as-is for context |
| `.md` | Markdown | Extracted as text context |
| `.csv` | CSV data | Read with pandas; auto-generates dashboard |
| `.xlsx / .xls` | Excel data | Read with pandas/openpyxl; auto-generates dashboard |
| `.pdf` | PDF document | Text extracted via PyMuPDF |
| `.docx` | Word document | Text extracted via python-docx |
| `.png / .jpg / .jpeg / .gif / .webp` | Images | Noted in context; describe via scenario |

---

## Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| `OPENAI_API_KEY` error on startup | Missing or placeholder key | Edit `.env`, set real `OPENAI_API_KEY` |
| `ModuleNotFoundError` | Venv not activated or deps not installed | `source .venv/bin/activate` then `pip install -r requirements.txt` |
| Port 5000 in use | Another process running | `lsof -ti:5000 \| xargs kill -9` (macOS/Linux) |
| File upload fails with type error | Blocked extension | Use supported file types only |
| LLM timeout | GPT-4o slow for large outputs | Increase `LLM_TIMEOUT_SECONDS` in `.env` to 120 |
| Dashboard not rendering | iframe sandbox | Try opening the downloaded HTML directly in browser |
| PPTX download empty | python-pptx not installed | `pip install python-pptx lxml` |
| PDF text extraction fails | PyMuPDF not installed | `pip install PyMuPDF` |
| Config not saving | `config/` directory missing | Run `mkdir config` in project root |

---

## Security Notes

- **API Key**: Loaded from `.env` only. Never hardcoded. Never logged or exposed in responses.
- **Prompt injection**: All user inputs sanitized and wrapped in XML delimiters before sending to GPT.
- **File uploads**: Filenames sanitized with `werkzeug.secure_filename`. Extension whitelist enforced. Executable files blocked.
- **File size**: Max 15MB per upload enforced at Flask and JS layers.
- **Path traversal**: Download endpoint validates all file paths stay within `generated/` directory.
- **No arbitrary code execution**: Uploaded files are read as text/binary only — never executed.
- **CORS**: Restricted to localhost origins only.
- **Content safety**: LLM responses scanned for harmful patterns before rendering.

---

## License

MIT License — free to use, modify, and distribute.

---

*VividPM AI v1.0.0 · Built with Flask + GPT-4o · Pure HTML/CSS/JS Frontend*
